<?php
/**
 * Created by nad.
 * Date: 07/03/2018
 * Time: 11:32
 * Description:
 */
?>
<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3>Dashboard</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Pemberitahuan<small>Kegiatan terakhir</small></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <ul class="list-unstyled timeline">
                        <li>
                            <div class="block">
                                <div class="tags">
                                    <a href="" class="tag">
                                        <span>10/02/2018</span>
                                    </a>
                                </div>
                                <div class="block_content">
                                    <h2 class="title">
                                        <a>13:20</a>
                                    </h2>
                                    <div class="byline">
                                    </div>
                                    <p class="excerpt">Proposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahanProposal kurang halaman pengesahan
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="block">
                                <div class="tags">
                                    <a href="" class="tag">
                                        <span>05/02/2018</span>
                                    </a>
                                </div>
                                <div class="block_content">
                                    <h2 class="title">
                                        <a>10:45</a>
                                    </h2>
                                    <div class="byline">
                                        <span></span>
                                    </div>
                                    <p class="excerpt">Judul TA : "Sistem Informasi Cuti Mahasiswa"
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="block">
                                <div class="tags">
                                    <a href="" class="tag">
                                        <span>10/01/2018</span>
                                    </a>
                                </div>
                                <div class="block_content">
                                    <h2 class="title">
                                        <a>14:52</a>
                                    </h2>
                                    <div class="byline">
                                        <span></span>
                                    </div>
                                    <p class="excerpt">Pendaftaran Tugas Akhir berhasil
                                    </p>
                                </div>
                            </div>
                        </li>
                    </ul>

                </div>
            </div>
        </div>
    </div>
</div>
